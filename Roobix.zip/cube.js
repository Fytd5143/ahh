pc.script.create('cube', function (app) {
	// Creates a new Cube instance
	var Cube = function (entity) {
		this.entity = entity;
		this._status = "intro";				// Current status of the cube
		this.boxes = [];					// All boxes in cube
		this.faces = [];					// All faces in cube
		this.surfaces = [];					// 6 surfaces with 9 faces each
		this.pickedFace 	= null;			// Face selected on pick
		this.activeFace 	= null;			// Active face, will deselect when new is picked
		this.faceAxis		= null;			// Axis which activeFace rests upon (x, y, or z)
		this.activeBox 		= null;			// Box with activeFace
		this.activeGroup 	= [];			// Array of 9 boxes to flip
		this.activePos 		= new pc.Vec3();// Position of activeBox
		this.soundManager;					// Will control sound effects
		this.pickSrc;
		this.moveSrc;
		this.pickTO;
		this.moveTO;
		this.boxCounter = 0;				// Counter to iterate through boxes
		this.faceCounter = 0;				// Counter to iterate through faces
		this.axes = ["x", "y", "z", "-x", "-y", "-z"];
		this.mute = false;
		this.rotatingCount = 0;				// Number of boxes that are rotating
		this.beats1 = 0;					// Whole beat
		this.beats4 = 0;					// Quarter beat
		this.beats16 = 0;					// Sixteenth beat
		this.whiteFace = app.assets.find("FaceWht");
		this.baseMaterial = app.assets.find("Base-cube").resource;
		this.onMaterials = {};				// On materials for faces
		this.lightTop = null;				// Top light
		this.lightBot = null;				// Bottom light
	};

	Cube.prototype = {
		// Called once after all resources are loaded and before the first update
		initialize: function(){
			// Will create array of only Boxes with Faces
			this.boxes = this.entity.getChildren().filter(function(thisChild){
				if(thisChild.getName() === "111"){
					return false;
				}else{
					return true;
				}
			});

			// Add box.js script to each box
			this.boxes.forEach(function(box, index){
				app.systems.script.addComponent(box,{
					scripts: [{url: "box.js"}]
				});
				this.faces.push.apply(this.faces, box.script.box.faces);
			}.bind(this));

			this.onMaterials = [
				app.assets.find("FaceBlu-on"),
				app.assets.find("FaceMag-on"),
				app.assets.find("FaceYel-on"),
				app.assets.find("FaceGrn-on"),
				app.assets.find("FacePrp-on"),
				app.assets.find("FaceRed-on")
			];
			this.lightTop = app.root.findByName("Top");
			this.lightBot = app.root.findByName("Bottom");

			this.soundManager = app.systems.audiosource.manager;
			this.pickSrc = this.entity.audiosource.data.sources.pick;
			this.moveSrc = this.entity.audiosource.data.sources.move;
		},

		// Called every frame, dt is time in seconds since last update
		update: function(dt){
			switch(this._status){
				case "whiteout":
					this.shuffleWhite(dt);
				break;
				case "colorize":
					this.shuffleColor(dt);
				break;
				case "intro":
					this.partyCubeUpdate(dt);
				break;
			}
		},

		// Lights up faces in party mode
		partyCubeUpdate: function(dt){
			this.beats1 += dt;
			this.beats4 += dt;
			this.beats16 += dt;

			if(this.beats1 > 2.05){ 			// Whole note
				this.beats1 %= 2.05;
				this.flickerLights(this.boxCounter);
				this.boxCounter ++;
			}

			if(this.beats4 > 0.5125){			// Quarter note
				this.beats4 %= 0.5125;
				if(!this.lightTop.enabled){
					this.baseMaterial.emissiveIntensity = 0.3;
					this.baseMaterial.update();
				}
			}else if(this.baseMaterial.emissiveIntensity > 0){
				this.baseMaterial.emissiveIntensity -= 0.05;
				this.baseMaterial.update();
			}

			if(this.beats16 > 0.128125){		// Sixteenth note
				this.beats16 %= 0.128125;
				this.lightRandomFace(true);
			}
		},

		// Turns partymode off
		partyCubeEnd: function(){
			this.baseMaterial.emissiveIntensity = 0;
			this.baseMaterial.update();
			this.flickerLights(1);
			this.lightRandomFace(false);
		},

		// Returns array of boxes in diagonal order
		makeDiagonalBoxes: function(){
			this.faces = [];
			var x = 0;
			var y = 0;
			var z = 0;
			var tempVec = new pc.Vec3.set(2,0,0);
			this.boxes.forEach(function(thisBox){
				for(x = 0; x < 3; x++){
					for(y = 0; y < 3; y++){
						for(z = 0; z < 3; z++){
							if(thisBox.script.box.getCoords() == x){

							}
						}
					}
				}
			});
		},

		// Rotate cube or box face
		rotate: function(axis){
			if(this._isBusy() || this._status !== ""){return false;}
			this._changeStatus("rotating");

			// If no face is selected, rotate whole cube
			if(this.activeFace === null){
				this.boxes.forEach(function(thisBox, index){
					if(thisBox.script.box.rotate(axis)){
						this.rotatingCount ++;
					}
				}.bind(this));
			}
			// Otherwise, only rotate boxes in desired axis
			else{
				this._makeGroup(axis, this.activeBox).forEach(function(thisBox){
					if(thisBox.script.box.rotate(axis)){
						this.rotatingCount ++;
					}
				}.bind(this));
			}
			this._sfxMove(axis);
		},

		// Select new active face
		faceSelect: function(){
			this.activeFace = this.pickedFace;
			this.activeBox = this.activeFace.getParent().getParent();
			this.faceAxis = this.activeBox.script.box.faceActivate(this.activeFace);
		},

		// Deselect active face
		faceDeselect: function(){
			if(this.activeFace === null){return false;}

			this.activeBox.script.box.faceDeactivate(this.activeFace);

			this.activeFace = null;
			this.activeBox = null;
			this.faceAxis = null;
		},

		// Deselect old face, select new face
		faceToggle: function(){
			this.faceDeselect();
			this.faceSelect();
		},

		////////////////////// CALLS FROM BOX.JS //////////////////////
		rotationComplete: function(auto){
			if(this._status === "autoShuffle"){
				this.rotatingCount --;
				if(this.rotatingCount === 0){
					this.shuffleFlip();
				}
			}else{
				this.rotatingCount --;
				if(this.rotatingCount === 0){
					this._changeStatus("");
				}
			}
		},

		////////////////////// CALLS FROM CAMERA.JS //////////////////////
		// New face picked
		pick: function(entity){
			// Avoids selecting faces on back side of cube
			if(entity.getName() === "111" || this._status !== ""){return false;}

			this.pickedFace = entity;
			
			// Deselects face if picking active one
			if(this.pickedFace == this.activeFace){
				this.faceDeselect();
			}
			// Selects new face if active doesn't exist
			else if(this.activeFace === null){
				this.faceSelect();
			}
			// Toggles faces if active already exists
			else{
				this.faceToggle();
			}
			this._sfxPick();
		},

		////////////////////// PARTYCUBE METHODS //////////////////////
		// Toggles lights on or off
		flickerLights: function(status){
			status %= 2;
			switch(status){
				case 1:
					this.lightTop.enabled = true;
					this.lightBot.enabled = true;
				break;
				case 0:
					this.lightTop.enabled = false;
					this.lightBot.enabled = false;
				break;
			}
		},

		// Lights cube body on/off
		flickerBody: function(){
			if(this.baseMaterial.emissiveIntensity === 1){
				this.baseMaterial.emissiveIntensity = 0;
			}else{
				this.baseMaterial.emissiveIntensity = 1;
			}
			this.baseMaterial.update();
		},

		// Lights random faces, or turns all off
		lightRandomFace: function(active){
			for(var i = 0; i < this.faces.length; i++){
				faceName = this.faces[i].getName();
				if(Math.random() < 0.1 && active){
					this.faces[i].model.materialAsset = app.assets.find(faceName + "-on");
				}else{
					this.faces[i].model.materialAsset = app.assets.find(faceName);
				}
			}
		},

		////////////////////// SHUFFLE METHODS //////////////////////
		// 1. Starts shuffle by checking status
		shuffleStart: function(){
			if(this._status !== "intro" && this._status !== ""){return false;}
			
			this._changeStatus("whiteout");
		},

		// 2. Turns one face white at a time
		shuffleWhite: function(dt){
			this.faces[this.faceCounter].model.materialAsset = this.whiteFace;
			this.faceCounter ++;
			if(this.faceCounter == this.faces.length){
				this._changeStatus("autoShuffle");
			}
		},

		// 3. Flips boxes automatically
		shuffleFlip: function(){
			if(this.boxCounter > 10){
				this._changeStatus("colorize");
			}else{ 
				var axisPos = Math.round(Math.random() * 2);
				this._autoRotate(this.axes[this.boxCounter % 6], axisPos);
				this._autoRotate(this.axes[(this.boxCounter + 3) % 6], (axisPos + 1) %3);
				this.boxCounter ++;
			}
		},

		// 4. Returns color to one face at a time
		shuffleColor: function(dt){
			this.faces[this.faceCounter].model.materialAsset = app.assets.find(this.faces[this.faceCounter].getName());
			this.faceCounter ++;
			if(this.faceCounter == this.faces.length){
				this._changeStatus("");
			}
		},

		freePlay: function(){
			if(this._status !== "intro" && this._status !== "")return;

			this._changeStatus("");
		},

		////////////////////// SUPERFLIP METHODS //////////////////////
		// 1. Starts superflip by checking status
		superflipStart: function(){
			if(this._status !== "intro" && this._status !== "")return;

			this._changeStatus("superflip");			
		},

		// 2. Assigns superflip status to all boxes
		superflipExecute: function(){
			var x = (Math.random() < 0.5) ? "-x" : "x";
			var y = (Math.random() < 0.5) ? "-y" : "y";
			var z = (Math.random() < 0.5) ? "-z" : "z";

			this.boxes.forEach(function(thisBox){
				switch(thisBox.script.box.type){
					case "edge":
						thisBox.script.box.superflip(x, 6);
					break;
					case "corner":
						thisBox.script.box.superflip(y, 3);
					break;
					case "center":
						thisBox.script.box.superflip(z, 0);
					break;
				}
				this.rotatingCount ++;
			}.bind(this));
		},

		// 3. Cube counts each box that completes superflip
		superflipComplete: function(){
			if(this._status === "superflip"){
				this.rotatingCount --;
				if(this.rotatingCount === 0){
					this._changeStatus("");
				}
			}
		},

		////////////////////// INTERNAL METHODS //////////////////////
		// Changes the status of the cube
		_changeStatus: function(newStatus){
			if(typeof(newStatus) !== "string")return;

			this.boxCounter = 0;
			this.faceCounter = 0;

			switch(this._status){
				case "superflip":
				break;
			};

			switch(newStatus){
				case "":
					if(this._status === "intro"){this.partyCubeEnd();}
					if(this._status === "rotating"){this._checkSolved();}
				break;
				case "intro":
				break;
				case "whiteout":
					this.partyCubeEnd();
				break;
				case "colorize":
				break;
				case "autoShuffle":
					this.shuffleFlip();
				break;
				case "rotating":
				break;
				case "superflip":
					this.partyCubeEnd();
					this.superflipExecute();
				break;
			};

			this._status = newStatus;
		},

		// Returns 9 boxes to flip, based on axis and a box
		_makeGroup: function(axis, axisBox){
			this.activeGroup = [];
			this.activePos = axisBox.script.box.getCoords();

			for(var i = 0; i < this.boxes.length; i++){
				if((axis === "x" || axis === "-x") && this.boxes[i].script.box.getCoords().x == this.activePos.x){
					this.activeGroup.push(this.boxes[i]);
				}
				else if((axis === "y" || axis === "-y") && this.boxes[i].script.box.getCoords().y == this.activePos.y){
					this.activeGroup.push(this.boxes[i]);
				}
				else if((axis === "z" || axis === "-z") && this.boxes[i].script.box.getCoords().z == this.activePos.z){
					this.activeGroup.push(this.boxes[i]);
				}
			}

			return this.activeGroup;
		},

		// Auto rotates group by taking axis name and position [0, 1, 2]
		_autoRotate: function(axis, axisPos){
			var x = 0;
			var y = 0;
			var z = 0;

			switch(axis){
				case "x":
				case "-x":
					x = axisPos;
				break;
				case "y":
				case "-y":
					y = axisPos;
				break;
				case "z":
				case "-z":
					z = axisPos;
				break;
			}

			this._makeGroup(axis, this._getBoxByPosition(x, y, z)).forEach(function(thisBox){
				if(thisBox.script.box.rotate(axis)){
					this.rotatingCount ++;
				}
			}.bind(this));
		},

		// Checks if cube is solved
		_checkSolved: function(){
			console.log("Checking for solvingness...");
			this._updateSurfaces();

			var j = 0;
			var compare = "";

			// Loops through surfaces to 
			for(var i = 0; i < this.surfaces.length; i++){
				compare = this.surfaces[i][0].getName();
				for(j = 1; j < this.surfaces[i].length; j++){
					if(compare !== this.surfaces[i][j].getName()){
						return;
					}
				}
			}

			alert("You won the game!");
		},

		// Populates 6 surfaces with 9 faces each
		_updateSurfaces:function(){
			var facePos = new pc.Vec3();
			this.surfaces = [[],[],[],[],[],[]];

			// Places each face in its corresponding surface
			for(var i = 0; i < this.faces.length; i++){
				facePos = this.faces[i].getPosition();
				if(facePos.x > 1.4){this.surfaces[0].push(this.faces[i]);}
				if(facePos.x < -1.4){this.surfaces[1].push(this.faces[i]);}
				if(facePos.y > 1.4){this.surfaces[2].push(this.faces[i]);}
				if(facePos.y < -1.4){this.surfaces[3].push(this.faces[i]);}
				if(facePos.z > 1.4){this.surfaces[4].push(this.faces[i]);}
				if(facePos.z < -1.4){this.surfaces[5].push(this.faces[i]);}
			}
		},

		// Returns true if any block is busy
		_isBusy: function(){
			for(var i = 0; i < this.boxes.length; i++){
				if(this.boxes[i].script.box.status !== ""){
					return true;
				}
			}
			return false;
		},

		////////////////////// UTILITIES //////////////////////
		_getBoxByPosition: function(x, y, z){
			var coordinates = "[" + (x - 1) + ", " + (y - 1) + ", " + (z - 1) + "]";
			for(var i = 0; i < this.boxes.length ; i++){
				if(this.boxes[i].script.box.getCoords().toString() == coordinates){
					return this.boxes[i];
				}
			}

			return false;
		},

		////////////////////// SOUND EFFECTS //////////////////////
		// Play Pick sound
		_sfxPick: function(){
			if(this.mute){return false;}
			/*var pickSnd = new pc.Channel(this.soundManager, this.pickSrc);
			pickSnd.startOffset = Math.round(Math.random() * 17);
			pickSnd.play();

			this.pickTO = window.setTimeout(function(){
				pickSnd.stop();
			}, 900);*/
		},

		// Play Move sound
		_sfxMove: function(axis){
			if(this.mute){return false;}
			/*var moveSnd = new pc.Channel(this.soundManager, this.moveSrc);
			moveSnd.startOffset = Math.round(Math.random() * 11) + 1;
			moveSnd.play();

			this.moveTO = window.setTimeout(function(){
				moveSnd.stop();
			}, 950);*/
		}
	};

	return Cube;
});