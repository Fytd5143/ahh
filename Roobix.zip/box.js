pc.script.create('box', function(app){
	// Creates a new Box instance
	var Box = function (entity){
		this.entity = entity;
		this.type = "";					// Corner, center, or edge
		this.status = "";				// Current action performed by box
		this.coord = new pc.Vec3();		// Coordinates (-1, 0, or 1)
		this.startPos = new pc.Vec3();	// Start position
		this.targPos = new pc.Vec3();	// Target position
		this.vecTemp = new pc.Vec3();	// Temp position for lerping
		this.faces;						// All faces
		this.base;						// Base for easy positioning
		this.cubicle;					// Entity containing faces + base
		this.quatNow = new pc.Quat();	// Current Quaternion
		this.quatTrg = new pc.Quat();	// Target Quaternion
		this.quatTmp = new pc.Quat();	// Temp Quaternion for lerping
		this.frameCount = 0;			// Frame counter
		this.t = 0;						// Time (0 - 1)
		this.speed = 2;					// Speed to speed up / slow down
	};

	Box.prototype = {
		// Called once after all resources are loaded and before the first update
		initialize: function(){
			if(this.type !== ""){return false;}
			// Filters children that aren't a face
			function isAFace(thisChild){
				if(thisChild.getName() === "Base"){
					return false;
				}else{
					return true;
				}
			}

			this.cubicle = this.entity.findByName("Cubicle");
			this.base = this.entity.findByName("Base");
			this.faces = this.cubicle.getChildren().filter(isAFace);
			this.setCoords();

			// Determines type of this box
			switch(this.entity.getName().split("1").length - 1){
				case 0: this.type = "corner"; 	break;
				case 1: this.type = "edge"; 	break;
				case 2: this.type = "center"; 	break;
			}
		},

		/////////////////////////// GETTERS/SETTERS ///////////////////////////
		// Sets target rotation
		setTargetRotation: function(axis){
			this.quatNow = this.entity.getRotation();

			// Add 90-degree rotation
			switch(axis){
				case "-x":
					this.quatTmp.setFromAxisAngle(pc.Vec3.RIGHT, -90);
				break;
				case "x":
					this.quatTmp.setFromAxisAngle(pc.Vec3.RIGHT, +90);
				break;
				case "-y":
					this.quatTmp.setFromAxisAngle(pc.Vec3.UP, -90);
				break;
				case "y":
					this.quatTmp.setFromAxisAngle(pc.Vec3.UP, +90);
				break;
				case "-z":
					this.quatTmp.setFromAxisAngle(pc.Vec3.FORWARD, -90);
				break;
				case "z":
					this.quatTmp.setFromAxisAngle(pc.Vec3.FORWARD, +90);
				break;
			}

			// Multiply to overall target rotation
			this.quatTrg.mul2(this.quatTmp, this.quatTrg);
		},
		
		// Sets current coordinates
		setCoords: function(){
			this.coord.set(
				Math.min(Math.max(Math.round(this.base.getPosition().x), -1), 1),
				Math.min(Math.max(Math.round(this.base.getPosition().y), -1), 1),
				Math.min(Math.max(Math.round(this.base.getPosition().z), -1), 1)
			);
		},

		// Returns coordinates if not busy
		getCoords: function(){
			if(this.status){
				return false;
			}else{
				return this.coord;
			}
		},

		// Returns random face
		getRandomFace: function(){
			return this.faces[Math.round(Math.random() * (this.faces.length - 1))];
		},

		/////////////////////////// CALLS FROM BOX.JS ///////////////////////////
		// Starts rotation process
		rotate: function(axis){
			if(this.status !== ""){return false;}
			this.speed = 2;
			this.setTargetRotation(axis);
			this.frameCount = 0;
			this.status = "rotating";
			return true;
		},

		// Starts superflip procedure
		superflip: function(axis, startDelay){
			this.speed = 2;
			this.setTargetRotation(axis);
			this.frameCount = startDelay * -1;
			this.startPos = pc.Vec3.ZERO;
			this.targPos = this.coord;
			this.status = "extruding";
		},

		// Lights up face, returns its axis
		faceActivate: function(face){
			// Substitute material to on state
			face.model.materialAsset = app.assets.find(face.getName() + "-on");

			// Returns axis
			if(Math.abs(face.getPosition().x) > 1.2){
				return "x";
			}
			else if(Math.abs(face.getPosition().y) > 1.2){
				return "y";
			}
			else if(Math.abs(face.getPosition().z) > 1.2){
				return "z";
			}
		},

		// Matte face material
		faceDeactivate: function(face){
			face.model.materialAsset = app.assets.find(face.getName());
		},

		// Turns face white
		faceWhiteout: function(face){
			face.model.materialAsset = app.assets.find("White");
		},

		/////////////////////////// ANIMATION UPDATERS ///////////////////////////
		// Called every frame, dt is time in seconds since last update
		update: function(dt){
			switch(this.status){
				case "rotating":
				case "superFlipping":
					this.updateRotation(dt);
				break;
				case "extruding":
				case "intruding":
					this.updateTranslation(dt);
				break;
			}
		},

		// Animates rotation
		updateRotation: function(dt){
			this.frameCount += (dt * this.speed);
			this.t = 1 - Math.pow((1 - this.frameCount), 3);
			this.entity.setRotation(this.quatTmp.slerp(this.quatNow, this.quatTrg, this.t));
			
			// When animation is over
			if(this.t >= 1){
				this.rotationComplete();
			}
		},

		// Animates translation
		updateTranslation: function(dt){
			this.frameCount += (dt * 2);
			if(this.frameCount >= 0){
				this.t = 1 - Math.pow((1 - this.frameCount), 3);
			}else{
				this.t = 0;
			}

			this.cubicle.setPosition(this.vecTemp.lerp(
				this.startPos,
				this.targPos,
				this.t
			));
			
			if(this.t >= 1){
				this.translationComplete();
			}
		},
		
		// At the end of a rotation
		rotationComplete: function(){
			this.frameCount = 0;
			this.setCoords();
			if(this.status === "superFlipping"){
				this.status = "intruding";
			}else{
				this.status = "";
				this.entity.getParent().script.cube.rotationComplete();
			}
		},

		// At the end of a translation
		translationComplete: function(){
			this.frameCount = 0;
			switch(this.status){
				case "extruding":
					this.startPos = this.targPos;
					this.targPos = pc.Vec3.ZERO;
					this.status = "superFlipping";
				break;
				case "intruding":
					this.status = "";
					this.setCoords();
					this.entity.getParent().script.cube.superflipComplete();
				break;
			}
		}
	};

	return Box;
});