pc.script.attribute('maxElevation', 'number', 70, {
	displayName: "Max Elevation"
});

pc.script.create("camera", function(app){
	 
	var Camera = function(entity){
		this.entity = entity;

		// Position
		this.tempVec = new pc.Vec3();
		// Distance
		this.distance = 3;
		this.targetDistance = 8;
		this.tempDistance = 8;
		// Rotations
		this.rotX = 0;
		this.rotY = 0;
		this.targetRotX = 1;
		this.targetRotY = 30;

		this.status = "autorotate";		// Keeps track of status of camera
		this.cubeScript = null;			// Connects to cube.js
		this.hammer = 0;				// Hammer object
		this.pinch = new pc.Vec2();		// Tracks pinch position
		this.activeTouch = false;		// Is there an active touchMove
		this.logVol = 1;				// Logarithmic volume
		this.timVol = null;				// Timeout to change volume

		this.w = 0;						// Width of canvas
		this.h = 0;						// Height of canvas
		app.mouse.disableContextMenu();
	};

	Camera.prototype = {
		initialize: function(){
			var touchOptions ={
				recognizers:[
					[Hammer.Pan,	{direction: Hammer.DIRECTION_ALL}],
					[Hammer.Pinch, 	{enable: true}],
					[Hammer.Press, 	{enable: true, time: 5}]
				]
			};

			// Touch events
			this.hammer = new Hammer(app.graphicsDevice.canvas, touchOptions);
			this.hammer.on('press', 		this.touchStart.bind(this));
			this.hammer.on('pressup', 		this.touchEnd.bind(this));
			this.hammer.on('pan', 			this.touchMove.bind(this));
			this.hammer.on('panend', 		this.touchEnd.bind(this));
			this.hammer.on('pinchstart',	this.touchPinchStart.bind(this));
			this.hammer.on('pinch', 		this.touchPinch.bind(this));
			this.hammer.on('pinchend', 		this.touchPinchEnd.bind(this));

			// Mouse events
			app.mouse.on(pc.input.EVENT_MOUSEMOVE, this.onMouseMove, this);
			app.mouse.on(pc.input.EVENT_MOUSEWHEEL, this.onMouseWheel, this);

			this.cubeScript = app.root.findByName("Cube").script.cube;

			// this.audioIntroPlay();
			window.addEventListener('orientationchange', this.getWH.bind(this));
			window.addEventListener('resize', this.getWH.bind(this));
			this.getWH();
		},
		
		update: function(dt){
			switch(this.status){
				case "autorotate":
					this.orbit(dt * 30, 0, true);
				break;
				case "centering":
					this.center(dt);
				break;
			}

			// Tweens distance and rotations
			if(this.rotX !== this.targetRotX || this.rotY !== this.targetRotY || this.distance !== this.targetDistance){
				this.tweenToTarget(dt);
			}

		},

		orbit: function(moveX, moveY, automatic){
			this.targetRotX += moveX;

			if(automatic){
				if(this.targetRotX > 360){
					this.targetRotX = (this.targetRotX % 360);
				}
			}else{
				this.targetRotY += moveY;
				this.targetRotX = pc.math.clamp(this.targetRotX, 270, 360);
			}

			this.targetRotY = pc.math.clamp(this.targetRotY, -this.maxElevation, this.maxElevation);
		},

		tweenToTarget: function(dt){
			// Rotation X
			this.rotX = (pc.math.lerpAngle(this.rotX, this.targetRotX, dt / 0.2)) % 360;
			if(Math.round(this.rotX * 100) === Math.round(this.targetRotX * 100)){
				this.rotX = this.targetRotX;
			}

			// Rotation Y
			this.rotY = pc.math.lerp(this.rotY, this.targetRotY, dt / 0.2);
			if(Math.round(this.rotY * 100) === Math.round(this.targetRotY * 100)){
				this.rotY = this.targetRotY;
			}

			// Distance
			this.distance = pc.math.lerp(this.distance, this.targetDistance, dt / 0.2);
			if(Math.round(this.distance * 100) === Math.round(this.targetDistance * 100)){
				this.distance = this.targetDistance;
			}

			// Set the camera's current position and orientation
			this.entity.setEulerAngles(-this.rotY, -this.rotX, 0);
			this.entity.setPosition(0, 0, 0);
			this.entity.translateLocal(0, 0, this.distance);
		},

		center: function(dt){
			if(this.targetRotX > 315){
				this.targetRotX = 315;
				this.status = "";
			}else{
				this.orbit(dt * 300, 0, true);
			}
		},

		onMouseWheel: function(event){
			event.event.preventDefault();
			this.targetDistance += event.wheel * -0.25;
			if (this.targetDistance < 6){
				this.targetDistance = 6;
			}
		},

		onMouseMove: function(event){
			if(this.status === "autorotate"){
				this.targetRotY = ((event.y / this.h) -1) * -70;
			}
			else if(event.buttons[pc.input.MOUSEBUTTON_RIGHT] && this.status === ""){
				this.orbit(event.dx * 0.2, event.dy * 0.2, false);
			}
		},

		////////////////////// MENU EVENTS //////////////////////
		// Tells cube to start shuffle, ends auto-rotation
		menuShuffle: function(){
			this.cubeScript.shuffleStart();
			this.targetRotY = 30;
			this.audioIntroFadeOut();
			this.status = "centering";
		},

		menuFreePlay: function(){
			this.cubeScript.freePlay();
			this.targetRotY = 30;
			this.audioIntroFadeOut();
			this.status = "centering";
		},

		menuSuperflip: function(){
			this.cubeScript.superflipStart();
			this.targetRotY = 30;
			this.audioIntroFadeOut();
			this.status = "centering";
		},

		////////////////////// TOUCH EVENTS //////////////////////
		// Selects a face
		touchStart: function(ev){
			var from = this.entity.getPosition();
			var to = this.entity.camera.screenToWorld(ev.center.x, ev.center.y, this.entity.camera.farClip);

			app.systems.rigidbody.raycastFirst(from, to, function(result){
				this.cubeScript.pick(result.entity);
			}.bind(this));

			this.activeTouch = true;
		},

		// Deselects active face
		touchEnd: function(ev){
			this.cubeScript.faceDeselect();
			this.activeTouch = false;
		},

		// Tracks movement, triggers rotations
		touchMove: function(ev){
			if(this.activeTouch === false){return false;}

			switch (this.cubeScript.faceAxis){
				case null:
					this.moveCube(ev);
				break;
				case "x":
					this.moveFaceX(ev);
				break;
				case "y":
					this.moveFaceY(ev);
				break;
				case "z":
					this.moveFaceZ(ev);
				break;
			}
		},

		// Set center of pinch
		touchPinchStart: function(ev){
			this.pinch.set(ev.center.x, ev.center.y);
		},

		// Pinch zooms and orbits
		touchPinch: function(ev){
			if(this.status !== "")return false;

			this.orbit((ev.center.x - this.pinch.x) * 0.2, (ev.center.y - this.pinch.y) * 0.2, false);
			this.pinch.set(ev.center.x, ev.center.y);

			this.targetDistance = this.tempDistance * (2 - ev.scale);
			if (this.targetDistance < 6){
				this.targetDistance = 6;
			}
		},

		// Pinch end
		touchPinchEnd : function(ev){
			this.tempDistance = this.targetDistance;
		},

		////////////////////// MOVE CUBE FACES //////////////////////
		moveCube: function(ev){
			// Checks X motion
			if(ev.deltaX < -10){
				this.cubeScript.rotate("-y");
				this.activeTouch = false;
			}else if(ev.deltaX > 10){
				this.cubeScript.rotate("y");
				this.activeTouch = false;
			}

			// Checks Y motion
			else if(ev.deltaY < -10){
				if(ev.center.x < this.w){
					this.cubeScript.rotate("-x");
				}else{
					this.cubeScript.rotate("-z");
				}
				this.activeTouch = false;
			}else if(ev.deltaY > 10){
				if(ev.center.x < this.w){
					this.cubeScript.rotate("x");
				}else{
					this.cubeScript.rotate("z");
				}
				this.activeTouch = false;
			}
		},

		moveFaceX:function(ev){
			// Left
			if(ev.deltaX < -10){
				this.cubeScript.rotate("-y");
				this.activeTouch = false;
			}
			// Right
			else if(ev.deltaX > 10){
				this.cubeScript.rotate("y");
				this.activeTouch = false;
			}
			// Up
			else if(ev.deltaY < -10){
				this.cubeScript.rotate("-z");
				this.activeTouch = false;
			}
			// Down
			else if(ev.deltaY > 10){
				this.cubeScript.rotate("z");
				this.activeTouch = false;
			}
		},

		moveFaceY:function(ev){
			// Up-left
			if(ev.deltaX < -10 && ev.deltaY < -10){
				this.cubeScript.rotate("-z");
				this.activeTouch = false;
			}
			// Up-right
			else if(ev.deltaX > 10 && ev.deltaY < -10){
				this.cubeScript.rotate("-x");
				this.activeTouch = false;
			}
			// Down-right
			else if(ev.deltaX > 10 && ev.deltaY > 10){
				this.cubeScript.rotate("z");
				this.activeTouch = false;
			}
			// Down-left
			else if(ev.deltaX < -10 && ev.deltaY > 10){
				this.cubeScript.rotate("x");
				this.activeTouch = false;
			}
		},

		moveFaceZ:function(ev){
			// Left
			if(ev.deltaX < -10){
				this.cubeScript.rotate("-y");
				this.activeTouch = false;
			}
			// Right
			else if(ev.deltaX > 10){
				this.cubeScript.rotate("y");
				this.activeTouch = false;
			}
			// Up
			else if(ev.deltaY < -10){
				this.cubeScript.rotate("-x");
				this.activeTouch = false;
			}
			// Down
			else if(ev.deltaY > 10){
				this.cubeScript.rotate("x");
				this.activeTouch = false;
			}
		},

		////////////////////// SOUNDS //////////////////////
		audioIntroPlay:function(){
			this.entity.audiosource.loop = true;
			this.entity.audiosource.volume = 1;
			this.entity.audiosource.play("intro");
		},

		audioIntroFadeOut:function(){
			window.clearTimeout(this.timVol);
			this.logVol -= 0.05;
			this.entity.audiosource.volume = this.logVol * this.logVol;
			if(this.logVol <= 0){
				this.logVol = 0;
				this.entity.audiosource.stop();
			}else{
				this.timVol = window.setTimeout(this.audioIntroFadeOut.bind(this), 100);
			}
		},

		audioIntroFadeIn:function(){
			window.clearTimeout(this.timVol);
			console.log(this.logVol);
			if(this.logVol <= 0){
				this.entity.audiosource.play("intro");
			}
			if(this.logVol < 1){
				this.timVol = window.setTimeout(this.audioIntroFadeIn.bind(this), 100);
			}
			this.logVol += 0.05;
			this.entity.audiosource.volume = this.logVol * this.logVol;
		},

		// Get the width and height
		getWH: function(){
			this.w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
			this.w /= 2;
			this.h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
			this.h /= 2;
		}
	};
	
	return Camera;
});